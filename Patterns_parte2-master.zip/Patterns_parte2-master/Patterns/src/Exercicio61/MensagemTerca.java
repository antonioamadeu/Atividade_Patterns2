package Exercicio61;

public class MensagemTerca implements MensagemDoDia {
	public void imprimir() {
		System.out.println("Hoje � ter�a-feira.");
	}
}
