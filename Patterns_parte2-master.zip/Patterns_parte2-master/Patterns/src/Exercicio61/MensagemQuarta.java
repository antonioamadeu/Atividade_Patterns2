package Exercicio61;

public class MensagemQuarta implements MensagemDoDia {
	public void imprimir() {
		System.out.println("Hoje � quarta-feira.");
	}
}
