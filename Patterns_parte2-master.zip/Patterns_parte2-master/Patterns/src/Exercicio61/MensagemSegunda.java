package Exercicio61;

public class MensagemSegunda implements MensagemDoDia {
	public void imprimir() {
		System.out.println("Hoje � segunda-feira.");
	}
}
